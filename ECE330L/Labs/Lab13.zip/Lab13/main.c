//"#include" statements for ADC and 7 segment function prototype declarations go here
// gpio_d_init() prototype declaration goes here!
#include "adc.h"
#include "seg7.h"
void gpio_d_init();
void DAC_init(void);
unsigned int *GPIOA_BASE = 0x40020000;
unsigned int *RCC_AHB1_ENR = 0x40023830;
unsigned int *RCC_APB1_ENR = 0x40023840;
unsigned int *GPIO_MODR = 0x40020000;
unsigned int *DAC_CR = 0x40007400;
unsigned int *DAC_RHR12R1 = 0x40007408;
int main(void)
{
     adc_init();
     seg7_init();
     adc_init();
     gpio_d_init();
     gpio_c_init();
     init_Reload();
	 DAC_init();
    
        unsigned char a[16] = {0x40,0x79,0x24,0x30,0x19,0x12,0x02,0x78,0x00,0x18,0x08,0x03,0x46,0x21,0x06,0x0e}; // set up array of 7 segment data to display decimal 		digits 
    while(1) {
    unsigned int q = 0;             // Initialize any variables needed
    adc_start();                // Start ADC
    
    while (!adc_done()) {
      q = q + 1;
                                // Wait in a tight loop for ADC conversion to finish
    }
    unsigned int val = adc_get();   // ADC is done; get ADC value (12 bits right justified)
	*DAC_RHR12R1 = val;

	if(val>(4095/2)){
	*DAC_RHR12R1 = 4095;
	}
	

	else {

	*DAC_RHR12R1 =0;

}

  
                                
  }

  return 0;                     // main function always returns 0 to indicate success
}

void init_Reload(void)
{ //calculating the reload value

}

void SysTick_Handler(void)     //ISR - SysTick Interrupt Service Routine

{
    if (i < 16)
    {
        *pLEDs |= (1 << i++);
    }
    else
    {
        *pLEDs = 0;
        i = 0;
    }
    //*pLEDs ^= (1<<15);
    //toggle Port D - LED 15
}


currentXDegrees = adc_get();            //gets x's adc
currentYDegrees = adc_get();            //gets y's adc


/*automatic*/  /*what is this???*/
if(testbit=(sw15,0)){                   //if on
    seg7_put(7,0x41);                   // HEX7 -- displays 'A'
    seg7_put(6,0x43);                   // HEX6 -- displays 'C'
    seg7_put(5,0x55);                   // HEX5 -- displays 'u' (up/down)
    seg7_put(4,0x4c);                   // HEX4 -- displays -- 'L' (left/right)



/*============= ([3] & [6]) Automatic mode switches from -90 to 90 ======================*/

x_degrees = currentXDegrees;            //gets x's currentdegree
y_degrees = currentYDegrees;            //gets y's currentdegree

if(val <=4095/2){                       //degrees should be -90
    do{
        x_degrees -=5;                          //50 levels of PWM resolution
        y_degrees -=5;
        seg7_put(3, x_degrees_tensPlace);       //HEX3 -- displays tens for x
        seg7_put(2, x_degrees_onesPlace);       //HEX2 -- displays ones for x
        seg7_put(1, y_degrees_tensPlace);       //HEX1 -- displays tens for y
        seg7_put(0, y_degrees_onesPlace);       //HEX0 -- displays ones for y
    }while (x_degrees != -90 & y_degrees != -90);
   
}else{                                  //degrees should be 90
     do{
        x_degrees +=5;                      //50 levels of PWM resolution
        y_degrees +=5;
    seg7_put(3, x_degrees_tensPlace);       //HEX3 -- displays tens for x
    seg7_put(2, x_degrees_onesPlace);       //HEX2 -- displays onesfor x
    seg7_put(1, y_degrees_tensPlace);       //HEX1 -- displays tens for y
    seg7_put(0, y_degrees_onesPlace);       //HEX0 -- displays ones for y

    }while (x_degrees != 90 & y_degrees != 90);
}
     
/*================================manual=========================================*/
}else if(testbit=(sw15,1)){             //if off
    seg7_put(7,0x20);                       // HEX7 -- blank
    seg7_put(6,0x4d);                       // HEX6--displays 'M'

    /*up/down determinant*/
    if(testbit=(sw0,0)){                //determining if changing up/down
         seg7_put(5,0x55);                  // HEX5 -- displays 'u'
         seg7_put(4,0x20);                  // HEX4 -- displays blank

         currentYDegrees = adc_get();       //manually changing the axis degrees
        
        seg7_put(1, currentYDegree_tensPlace);       //HEX1 -- displays tens for y
        seg7_put(0, currentYDegree_onesPlace);       //HEX1 -- displays tens for y

        /*left/right*/
    } else if((testbit=(sw0,1)){
        seg7_put(5,0x20);                   // HEX5 -- displays blank
        seg7_put(4,0x4c);                   // HEX4 -- displays -- 'L'

        currentXDegrees = adc_get();        //MANUALLY SETTING THE X AXIS

        seg7_put(3, currentXDegrees_tensPlace);       //HEX3 -- displays tens for x
        seg7_put(2, currentXDegrees_onesPlace);       //HEX2 -- displays tens for x
    }

    /*Speed of value change*/
else if(testbit=(sw0,0) && testbit=(sw0,1) ) {
    if(val <=4095/2){
        seg7_put(3, currentXDegrees_tensPlace);       //HEX3 -- displays tens for x
        seg7_put(2, currentXDegrees_onesPlace);       //HEX2 -- displays tens for x
        seg7_put(1, currentYDegree_tensPlace);        //HEX1 -- displays tens for y
        seg7_put(0, currentYDegree_onesPlace);        //HEX1 -- displays tens for y

        /*while obtaining input set appropriate input values
          to currentXdegrees_tens and ones varaible*/
      
        /*use currentXdegrees_tensand ones variables to display on seg7 and servo motors*/

     


}



}


}
    
}


